package catandmousegame;

/**
 *
 * @author Duarte
 */

public class GameMain {
public static void main(String[] args) {

    GameLogic logica = new GameLogic();
    logica.run();
    //boolean test = logica.buscarRepetidos(1, 2);
    //System.out.println(test);
    
}
}
