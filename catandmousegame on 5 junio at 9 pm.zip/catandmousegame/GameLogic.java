package catandmousegame;

/**
 *
 * @author Duarte
 */
import java.util.*;

public class GameLogic {

    Scanner sc = new Scanner(System.in);
    int option = 0, numJuegosJugados = 0, numJuegosGanados = 0, numIntento = 0, puntoX = 0, puntoY = 0, respuestaX = 0, respuestaY = 0;
    boolean encontrado = false, repetidos = false;
    char respuesta;
    int[][] puntosRepetidos = new int[5][5];
    Random generator = new Random();

    public void mostrarInstrucciones() {
        System.out.println("Bienvenuto al juego del gato y el raton. Las instrucciones son sencillas, "
                + "\ntienes 5 oportunidades antes de que el raton se escape."
                + "\nTienes que ingresar coordenadas en formato X,Y."
                + "\nEl tablero es una matriz de 5 por 5"
                + "\n*****"
                + "\n*****"
                + "\n*****"
                + "\n*****"
                + "\n*****"
                + "\nIngresa la opcion deseada (1 - Jugar, 2 - Salir)");
    }

    public void run() {
        this.mostrarInstrucciones();

        try {
            System.out.println("Do you wanna play? ");
            option = sc.nextInt();
            sc.nextLine();
        } catch (Exception ex) {
            System.out.println("No ingresaste una opcion valida.");
            System.exit(0);
        }

        switch (option) {
            case 1:
                play();
            case 2:
                System.out.println("Bueno, ciao, ciao!");
                System.exit(0);
            default:
                System.out.println("Opcion incorrecta. Exiting!!!!");
                System.exit(0);
        }
    }

    public boolean atrapar(int X, int Y) {

        System.out.println("Los puntos que ingresaste son: " + X + "," + Y);

        if (respuestaX == puntoX && respuestaY == puntoY) {
            encontrado = true;
        }
        return encontrado;
    }

    public boolean buscarRepetidos(int X, int Y) {

        System.out.println("Los puntos a comparar son: " + X + "," + Y);
        

        /*
        for (int x = 0; x < puntosRepetidos.length; x++) {
            for (int y = 0; y < puntosRepetidos[x].length; y++) {
                System.out.println("Introduzca el elemento [" + x + "," + y + "]");
                puntosRepetidos[x][y] = sc.nextInt();
            }
        }
*/

        return repetidos;
    }

    public void play() {

        respuestaX = generator.nextInt(5);
        respuestaY = generator.nextInt(5);
        numJuegosJugados++;

        do {
            numIntento++;
            System.out.println("Este es tu " + numIntento + " intento. Good luck!");
            try {
                System.out.println("Que punto quieres para X?");
                puntoX = sc.nextInt();
                sc.nextLine();
                System.out.println("Que punto quieres para Y?");
                puntoY = sc.nextInt();
                sc.nextLine();
            } catch (Exception ex) {
                System.out.println("No ingresaste una opcion valida.");
                System.exit(0);
            }

            repetidos = buscarRepetidos(puntoX, puntoY);

            if (repetidos == true) {
                encontrado = atrapar(puntoX, puntoY);
            }

        } while (numIntento <= 5 && encontrado == false);

        if (encontrado) {
            numJuegosGanados++;
            System.out.println("Great!, haz encontrado al raton!! \nEstaba escondido en el punto ("
                    + puntoX + " , " + puntoY
                    + ") \nLo encontraste en tu " + numIntento + "intento.");
        } else {
            System.out.println("Sorry, esta vez no tuviste suerte.");
        }

        try {
            System.out.println("Quieres seguir jugando?");
            respuesta = sc.next().charAt(0);
            sc.nextLine();
        } catch (Exception ex) {
            System.out.println("No ingresaste una opcion valida.");
            System.exit(0);
        }

        if (respuesta == 'Y' || respuesta == 'y') {
            jugarOtraVez();
        } else {
            System.out.println("Jugaste: " + numJuegosJugados + ". Haz ganado: " + numJuegosGanados);
            System.out.println("Ciao amici");
        }

    }

    public void jugarOtraVez() {
        numIntento = 0;
        respuestaX = 0;
        respuestaY = 0;
        puntoX = 0;
        puntoY = 0;
        encontrado = false;
        play();
    }

    public void exit() {
        System.exit(0);
    }

}
