package catandmousegame;

/**
 *
 * @author Duarte
 */
public class Cat {
    
}
