package catandmousegame;

/**
 *
 * @author Duarte
 */
public class Mouse {
    
}
