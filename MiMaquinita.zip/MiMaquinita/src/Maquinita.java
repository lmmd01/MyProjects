import java.util.*;

public class Maquinita {
public static void main(String[] args) {
    
    int apuesta = 0, balanceRestante = 0,juegosDoblesGanados = 0, juegosTriplesGanados = 0;
    int slot1 = 0, slot2 = 0, slot3 = 0;

    Random generator = new Random();
    System.out.println("Tu balance es: $" + balanceRestante);
    Scanner teclado=new Scanner(System.in);
    System.out.print("Ingresa la cantidad a jugar $: ");
    apuesta = teclado.nextInt();
    balanceRestante =+ apuesta;
    System.out.println("Muy bien, ahora tienes $: " + balanceRestante);
  
    // Implementar un while or do while en lugar del if
    if (balanceRestante > 0){
        slot1 = generator.nextInt(10);
        slot2 = generator.nextInt(10);
        slot3 = generator.nextInt(10);
        //slot1 = 3;
        //slot2 = 3;
        //slot3 = 3;
        System.out.println("Haz obtenido las siguientes combinaciones: " 
                + slot1 + "---" + slot2 + "---" + slot3);
        
        if(slot1 == slot2 && slot2 == slot3 && slot1 == slot3){
            balanceRestante += 10;
            System.out.println("Hiciste triple. Ahora tienes : " + balanceRestante);
            juegosTriplesGanados++;
        }else if (slot1 == slot2 || slot2 == slot3 || slot1 == slot3  ){
            balanceRestante += 5;
            System.out.println("Hiciste doble. Ahora tienes : " + balanceRestante);
            juegosDoblesGanados++;
        }else{
            balanceRestante -= 5;
            System.out.println("Not this time, my friend. Te quedan: " + balanceRestante + " pesos");
        }
    }else if(balanceRestante <= 0){
        System.out.println("Ya no tienes creditos. Ciao amici");
    }teclado.close();
}
}